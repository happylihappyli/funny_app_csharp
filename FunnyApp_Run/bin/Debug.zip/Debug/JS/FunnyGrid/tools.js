
function tree_init(data){

    s_ui.Tree_Add_Node_Root("tree1","root","我的电脑","Node_Click");
    s_ui.Tree_Add_Node("tree1","root","test","test","Node_Click");
    s_ui.Tree_Add_Node_Root("tree1","C","C:","Node_Click");
    s_ui.Tree_Add_Node_Root("tree1","D","D:","Node_Click");
    s_ui.Tree_Add_Node_Root("tree1","E","E:","Node_Click");
}
