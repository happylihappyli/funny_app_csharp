
s_ui.Show_Form(560,500);

s_ui.Form_Title("显示");


s_ui.Run_App("chrome.exe","E:/CloudStation/Robot5/GitHub/funny_app_java/funny_app/test/test.html");

sys.Exit();