var friend_return=0;
var log_msg="";
var msg_id=0;
var myMap=[];

