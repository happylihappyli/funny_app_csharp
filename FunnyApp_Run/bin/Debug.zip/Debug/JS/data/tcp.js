var friend_return=0;
var msg_id=0;
var myMap=[];

